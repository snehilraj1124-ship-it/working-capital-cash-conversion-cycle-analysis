# Working Capital & Cash Conversion Cycle Analysis

## Meridian Consumer Products Ltd.

A comprehensive working-capital management project analyzing the operating cash cycle of a fictional consumer-products company.

## Project Objective

The project evaluates how efficiently a business converts operating activity into cash and identifies opportunities to reduce cash tied up in:

- Accounts Receivable
- Inventory
- Accounts Payable
- Net Working Capital

The analysis combines financial ratios, operating metrics, scenario analysis, risk management and an implementation roadmap.

## Core Metrics

### Days Sales Outstanding (DSO)

Measures the average number of days required to collect customer receivables.

**DSO = Accounts Receivable / Revenue × 365**

### Days Inventory Outstanding (DIO)

Measures the average number of days inventory remains in the operating cycle.

**DIO = Inventory / COGS × 365**

### Days Payables Outstanding (DPO)

Measures the average number of days taken to pay suppliers.

**DPO = Accounts Payable / COGS × 365**

### Cash Conversion Cycle (CCC)

**CCC = DSO + DIO − DPO**

A lower CCC generally indicates that less cash is tied up in the operating cycle, provided service levels and supplier relationships remain healthy.

## Base-Case FY2026 Snapshot

- Sales: INR 2,020 crore
- COGS: INR 1,280 crore
- Inventory: INR 280 crore
- Receivables: INR 270 crore
- Payables: INR 205 crore
- Modeled CCC: 70.2 days

## FY2027 Illustrative Targets

- DSO: 52 days
- DIO: 72 days
- DPO: 60 days
- Target CCC: 64 days
- Illustrative cash-release opportunity: INR -13.8 crore

## Analysis Included

1. Historical working-capital dataset
2. DSO analysis
3. DIO analysis
4. DPO analysis
5. Cash Conversion Cycle analysis
6. Net Working Capital analysis
7. Liquidity ratio analysis
8. Receivables management strategy
9. Inventory management strategy
10. Payables management strategy
11. CCC scenario analysis
12. Cash-release opportunity
13. Working-capital risk register
14. Governance framework
15. FY2027 target setting
16. Implementation roadmap
17. KPI dashboard
18. Financial impact assessment
19. Strategic recommendations
20. Final conclusion

## Repository Structure

```text
working-capital-cash-conversion-cycle-analysis/
│
├── README.md
├── PDF_Files/
│   ├── 01_Cover.pdf
│   ├── 02_Executive_Summary.pdf
│   ├── 03_Business_Context.pdf
│   ├── 04_Methodology.pdf
│   ├── 05_Historical_Dataset.pdf
│   ├── 06_DSO_Analysis.pdf
│   ├── 07_DIO_Analysis.pdf
│   ├── 08_DPO_Analysis.pdf
│   ├── 09_Cash_Conversion_Cycle.pdf
│   ├── 10_Net_Working_Capital.pdf
│   ├── 11_Liquidity_Analysis.pdf
│   ├── 12_Receivables_Management.pdf
│   ├── 13_Inventory_Management.pdf
│   ├── 14_Payables_Management.pdf
│   ├── 15_CCC_Scenario_Analysis.pdf
│   ├── 16_Cash_Release_Opportunity.pdf
│   ├── 17_Risk_Analysis.pdf
│   ├── 18_Working_Capital_Governance.pdf
│   ├── 19_Target_Setting.pdf
│   ├── 20_Implementation_Roadmap.pdf
│   ├── 21_KPI_Dashboard.pdf
│   ├── 22_Financial_Impact.pdf
│   ├── 23_Strategic_Recommendations.pdf
│   ├── 24_Conclusion.pdf
│   └── 25_Appendix_&_Disclosure.pdf
│
├── Data/
│   ├── 01_Working_Capital_Historical.csv
│   ├── 02_Assumptions_Targets.csv
│   ├── 03_CCC_Scenarios.csv
│   ├── 04_Risk_Register.csv
│   ├── 05_KPI_Dashboard.csv
│   └── Working_Capital_CCC_Model.xlsx
│
└── Charts/
    ├── 01_Cycle_Components.png
    ├── 02_CCC_Trend.png
    ├── 03_NWC_Trend.png
    ├── 04_Cash_Release.png
    └── 05_KPI_Snapshot.png
```

## Tools Used

- Microsoft Excel
- Financial Modeling
- Working Capital Analysis
- Cash Conversion Cycle Analysis
- Financial Ratio Analysis
- Scenario Analysis
- Risk Management
- Data Visualization
- KPI Development

## Skills Demonstrated

- Working Capital Management
- Cash Flow Management
- Financial Analysis
- DSO / DIO / DPO Analysis
- Cash Conversion Cycle
- Liquidity Analysis
- Receivables Management
- Inventory Management
- Payables Management
- Financial Modeling
- Scenario Planning
- Risk Management
- Strategic Financial Management
- KPI Development

## Strategic Recommendations

1. Make CCC a formal management KPI.
2. Improve customer collections and reduce overdue receivables.
3. Use ABC inventory classification and SKU-level monitoring.
4. Optimize supplier payment terms within contractual limits.
5. Maintain a rolling working-capital forecast.
6. Establish weekly cash-cycle monitoring.
7. Track actual cash release against the original baseline.
8. Reassess targets regularly as the business grows.

## Important Disclosure

**Meridian Consumer Products Ltd. is a fictional company created specifically for this portfolio project.**

All historical figures, targets, assumptions, scenarios, ratios and cash-release estimates are **synthetic/illustrative**.

They do not represent an actual company, actual financial statements or an actual management forecast.

This project is intended for **portfolio, educational and demonstration purposes only**.

## Author

**Snehil Raj**

B.Tech — Electrical & Electronics Engineering

Areas of Interest:

- Financial Management
- Corporate Finance
- Business Analytics
- Strategic Management
- Investment Analysis
- MBA

---

⭐ **Portfolio Project — Working Capital & Cash Conversion Cycle Analysis**
